Compile settings:
Version 0.8.18
Evm: Paris
Optimization: 200

*_flattened.sol - flat versions for verify