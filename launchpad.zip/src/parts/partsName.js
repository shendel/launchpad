export const partsName = {
    body: ["white", "brown", "black"],
    eyes: ["pointy","cute","cool", "insomnia"],
    head: ["prisoner","joker","monk","police","soilder",  "pilot", "king"],
    shirt: ["prisoner","joker","monk","police","soilder",  "pilot", "king"],
    accessory: ["prisoner","joker","monk","police","soilder",  "pilot", "king"],
  };